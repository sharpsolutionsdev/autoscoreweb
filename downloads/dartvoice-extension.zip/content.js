(function () {
  if (window.__dartvoiceInjected) return;
  window.__dartvoiceInjected = true;

  // --- DART PARSING LOGIC PORTED FROM PYTHON ---
  const _ONES = { 'zero': 0, 'oh': 0, 'one': 1, 'two': 2, 'three': 3, 'four': 4, 'five': 5, 'six': 6, 'seven': 7, 'eight': 8, 'nine': 9, 'ten': 10, 'eleven': 11, 'twelve': 12, 'thirteen': 13, 'fourteen': 14, 'fifteen': 15, 'sixteen': 16, 'seventeen': 17, 'eighteen': 18, 'nineteen': 19 };
  const _TENS = { 'twenty': 20, 'thirty': 30, 'forty': 40, 'fifty': 50, 'sixty': 60, 'seventy': 70, 'eighty': 80, 'ninety': 90 };

  const _CRICKET_MODS = { 'single': 1, 'double': 2, 'treble': 3, 'triple': 3, 'travel': 3, 'trouble': 3, 'tribal': 3, 'tremble': 3, 'trickle': 3, 'doubles': 2, 'singles': 1 };

  const _CRICKET_TARGETS = {
    'twenty': '20', 'twenties': '20', '20': '20', 'plenty': '20',
    'nineteen': '19', 'nineteens': '19', '19': '19',
    'eighteen': '18', 'eighteens': '18', '18': '18',
    'seventeen': '17', 'seventeens': '17', '17': '17',
    'sixteen': '16', 'sixteens': '16', '16': '16',
    'fifteen': '15', 'fifteens': '15', '15': '15',
    'bull': 'b', 'bullseye': 'b', 'bulls': 'b', 'bowl': 'b', 'bold': 'b', 'pull': 'b', 'full': 'b',
    'miss': 'miss', 'zero': 'miss', 'nothing': 'miss', 'none': 'miss', 'missed': 'miss'
  };

  const _SHORTHAND_RE = /^([sdt])(\d{2}|bull?)$/;
  const _SHORTHAND_TARGETS = { '20': '20', '19': '19', '18': '18', '17': '17', '16': '16', '15': '15', 'bul': 'b', 'bull': 'b', 'b': 'b' };

  function parseCricketDarts(text) {
    const words = text.toLowerCase().replace(/-/g, ' ').split(' ');
    let darts = [];
    let currentMod = 's';

    for (const w of words) {
      // Shorthand match (e.g., t20, d16)
      const sh = w.match(_SHORTHAND_RE);
      if (sh) {
        const m = sh[1];
        const tgt = _SHORTHAND_TARGETS[sh[2]];
        if (tgt) {
          darts.push({ tgt: tgt, mod: (tgt === 'b' && m === 't' ? 's' : m) });
          continue;
        }
      }
      // Modifier match
      let numMod = _CRICKET_MODS[w];
      if (numMod) {
        if (numMod === 3) currentMod = 't';
        else if (numMod === 2) currentMod = 'd';
        else currentMod = 's';
      } else if (_CRICKET_TARGETS[w]) {
        // Target match
        const tgt = _CRICKET_TARGETS[w];
        if (tgt === 'miss') {
          darts.push({ tgt: 'miss', mod: 'none' });
        } else {
          darts.push({ tgt: tgt, mod: (tgt === 'b' && currentMod === 't' ? 's' : currentMod) });
        }
        currentMod = 's'; // reset modifier after target
      }
    }
    return darts.slice(0, 3);
  }

  function parseUnder100(t) {
    if (_ONES[t] !== undefined) return _ONES[t];
    if (_TENS[t] !== undefined) return _TENS[t];
    const w = t.split(' ');
    if (w.length === 2 && _TENS[w[0]] !== undefined && _ONES[w[1]] !== undefined) {
      return _TENS[w[0]] + _ONES[w[1]];
    }
    const v = parseInt(t);
    return (!isNaN(v) && v >= 0 && v <= 99) ? v : null;
  }

  function parseScore(text) {
    text = text.toLowerCase().replace(/\band\b/g, ' ').replace(/\s+/g, ' ').trim();
    return parseUnder100(text); // Basic integer mapping for MVP X01
  }

  function parseSingleDart(text) {
    let t = text.toLowerCase().replace(/\s+/g, ' ').trim();
    if (['bull', 'bullseye', 'bulls', 'fifty', 'double bull'].includes(t)) return { val: 50, label: 'Bull' };
    if (['outer bull', 'twenty five', 'twenty-five', 'half bull', 'single bull', 'green bull'].includes(t)) return { val: 25, label: '25' };
    if (['miss', 'missed', 'zero', 'nothing', 'none', 'bounce out', 'bounce'].includes(t)) return { val: 0, label: 'Miss' };

    let words = t.split(' ');
    let mod = 1, pfx = '';

    if (words.length > 0 && _CRICKET_MODS[words[0]] !== undefined) {
      mod = _CRICKET_MODS[words[0]];
      if (mod === 3) pfx = 'T';
      else if (mod === 2) pfx = 'D';
      words = words.slice(1);
    }
    if (words.length === 0) return null;

    let val = parseUnder100(words.join(' '));
    if (val === null) return null;

    if (val >= 1 && val <= 20) {
      return { val: val * mod, label: (pfx ? pfx + val : '' + val) };
    }
    return null;
  }

  // --- STATE ---
  let isListening = false;
  let recognition = null;
  let calibrationMode = false;
  let calibratedCoords = { x: null, y: null };
  
  // Load persisted calibration
  chrome.storage.local.get(['calibratedCoords'], (result) => {
    if (result.calibratedCoords) {
      calibratedCoords = result.calibratedCoords;
      logTrace(`Restored Persisted Calibration: X=${calibratedCoords.x}, Y=${calibratedCoords.y}`);
    }
  });
  const isDartVoiceParent = window.location.href.includes('web-app.html') || window.location.href.includes('dartvoice-dashboard.html');
  const isIframe = window !== window.top;

  if (isDartVoiceParent) {
      logTrace("Detected DartVoice Dashboard. Disabling internal microphone to avoid conflicts.");
  }

  const frameID = isIframe ? "[IFRAME]" : "[PARENT]";

  const style = document.createElement('style');
  style.textContent = `
    @import url('https://fonts.googleapis.com/css2?family=Barlow+Condensed:ital,wght@0,400;0,600;0,700;0,900;1,700;1,900&family=Plus+Jakarta+Sans:wght@400;500;600;700&display=swap');
    
    .dv-panel {
      background: rgba(8, 8, 10, 0.85);
      backdrop-filter: blur(12px);
      -webkit-backdrop-filter: blur(12px);
      color: #F0F0F5;
      padding: 20px;
      border-radius: 16px;
      width: 280px;
      box-shadow: 0 10px 40px rgba(0,0,0,0.8), inset 0 1px 1px rgba(255,255,255,0.05);
      border: 1px solid rgba(255,255,255,0.08);
      position: relative;
      font-family: 'Plus Jakarta Sans', sans-serif;
    }
    
    .header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 16px;
      border-bottom: 1px solid rgba(255,255,255,0.05);
      padding-bottom: 12px;
    }
    
    h3 {
      margin: 0;
      font-family: 'Barlow Condensed', sans-serif;
      font-size: 22px;
      font-weight: 900;
      font-style: italic;
      letter-spacing: -0.02em;
      text-transform: uppercase;
      color: white;
    }
    
    .text-red { color: #CC0B20; }
    
    .close-btn {
      cursor: pointer;
      color: #6E6E82;
      font-size: 16px;
      transition: color 0.2s;
    }
    .close-btn:hover { color: #fff; }
    
    .status-row {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 16px;
      font-size: 11px;
      font-weight: 700;
      letter-spacing: 0.1em;
      text-transform: uppercase;
      color: #6E6E82;
    }
    
    .status-dot { width: 8px; height: 8px; border-radius: 50%; background: #6E6E82; display: inline-block; }
    .status-dot.active { background: #CC0B20; box-shadow: 0 0 10px #CC0B20; }
    
    button {
      background: rgba(37,37,48,0.5);
      color: #F0F0F5;
      border: 1px solid rgba(255,255,255,0.05);
      padding: 10px 14px;
      border-radius: 8px;
      cursor: pointer;
      width: 100%;
      margin-bottom: 10px;
      font-weight: 700;
      font-size: 11px;
      font-family: 'Plus Jakarta Sans', sans-serif;
      text-transform: uppercase;
      letter-spacing: 0.05em;
      transition: all 0.2s;
    }
    button:hover { background: rgba(37,37,48,0.8); }
    
    button.primary {
      background: #CC0B20;
      border-color: transparent;
      box-shadow: 0 0 15px rgba(204,11,32,0.3);
    }
    button.primary:hover {
      background: #e60d24;
      box-shadow: 0 0 20px rgba(204,11,32,0.5);
      transform: translateY(-1px);
    }
    button.primary:active { transform: translateY(1px); }
    
    .log {
      font-size: 11px;
      font-weight: 500;
      color: #aaabbb;
      background: #111114;
      padding: 12px;
      border-radius: 8px;
      min-height: 50px;
      margin-top: 16px;
      word-wrap: break-word;
      border: 1px solid rgba(255,255,255,0.03);
      line-height: 1.4;
    }
  `;
  shadow.appendChild(style);

  const panel = document.createElement('div');
  panel.className = 'dv-panel';
  panel.innerHTML = `
    <div class="header">
      <h3>DART<span class="text-red">VOICE</span> overlay</h3>
      <span class="close-btn" id="dv-close">✖</span>
    </div>
    <div class="status-row">
      <span id="dv-status-text">Microphone Idle</span>
      <div class="status-dot" id="dv-status-dot"></div>
    </div>
    <button id="dv-toggle-mic" class="primary">Start Listening</button>
    <button id="dv-calibrate">Calibrate Grid</button>
    <div class="log" id="dv-log">Awaiting voice commands...</div>
  `;
  shadow.appendChild(panel);

  const statusText = shadow.getElementById('dv-status-text');
  const statusDot = shadow.getElementById('dv-status-dot');
  const toggleMicBtn = shadow.getElementById('dv-toggle-mic');
  const calibrateBtn = shadow.getElementById('dv-calibrate');
  const logDiv = shadow.getElementById('dv-log');
  const closeBtn = shadow.getElementById('dv-close');

  function logTrace(msg, data) {
    const timestamp = new Date().toLocaleTimeString();
    const prefix = `[DartVoice Bridge ${frameID}]`;
    if (data) console.log(`${prefix} ${msg}`, data);
    else console.log(`${prefix} ${msg}`);
  }

  // --- AUTO-COOKIE DISMISSAL ---
  function autoDismissCookies() {
      const cookieBtn = document.querySelector('button.cm__btn:nth-of-type(1)');
      if (cookieBtn && cookieBtn.textContent.toLowerCase().includes('accept')) {
          logTrace("Auto-dismissing cookie consent modal...");
          cookieBtn.click();
      }
  }
  
  // Check for cookies periodically
  const cookieInterval = setInterval(autoDismissCookies, 2000);
  setTimeout(() => clearInterval(cookieInterval), 20000); // Stop after 20s

  logTrace("Extension Script Injected and Ready.");

  // --- CALIBRATION OVERLAY ---
  let calibrationOverlay = null;

  function startCalibration() {
    calibrationMode = true;
    logTrace("Calibration Mode activated. Spawning overlay.");
    panel.style.opacity = '0.5';

    // Create the dark overlay
    calibrationOverlay = document.createElement('div');
    calibrationOverlay.style.position = 'fixed';
    calibrationOverlay.style.inset = '0';
    calibrationOverlay.style.backgroundColor = 'rgba(0, 0, 0, 0.85)';
    calibrationOverlay.style.zIndex = '2147483647'; // Max integer to ensure it's on top of everything
    calibrationOverlay.style.display = 'flex';
    calibrationOverlay.style.flexDirection = 'column';
    calibrationOverlay.style.alignItems = 'center';
    calibrationOverlay.style.justifyContent = 'center';
    calibrationOverlay.style.cursor = 'crosshair';
    
    // Add textual instructions
    calibrationOverlay.innerHTML = `
      <div style="text-align: center; color: white; font-family: sans-serif; pointer-events: none;">
        <h1 style="font-size: 32px; font-weight: bold; margin-bottom: 16px; color: #CC0B20; text-transform: uppercase; letter-spacing: 2px;">Calibration Mode</h1>
        <p style="font-size: 18px; color: #F0F0F5;">Click exactly on the DartCounter Score Input Box.</p>
      </div>
    `;

    document.body.appendChild(calibrationOverlay);

    // Listen for the calibration click strictly on the overlay
    calibrationOverlay.addEventListener('mousedown', (e) => {
      e.preventDefault();
      e.stopPropagation();
      
      calibratedCoords = { x: e.clientX, y: e.clientY };
      calibrationMode = false;
      
      // Persist to storage
      chrome.storage.local.set({ calibratedCoords });
      
      logTrace(`Coordinate Calibrated: X=${e.clientX}, Y=${e.clientY}`);
      
      // Destroy the overlay instantly
      document.body.removeChild(calibrationOverlay);
      calibrationOverlay = null;
    }, true);
  }

  calibrateBtn.addEventListener('click', () => {
    startCalibration();
  });

  // --- CLICK SIMULATION ---
  function clickCoordinate(x, y) {
    const el = document.elementFromPoint(x, y);
    if (el) {
      logTrace("Simulating click on target element:", el);
      // Simulate physical click
      el.dispatchEvent(new MouseEvent('mousedown', { bubbles: true, cancelable: true, clientX: x, clientY: y }));
      el.dispatchEvent(new MouseEvent('mouseup', { bubbles: true, cancelable: true, clientX: x, clientY: y }));
      el.dispatchEvent(new MouseEvent('click', { bubbles: true, cancelable: true, clientX: x, clientY: y }));
      el.focus();
    } else {
      logTrace(`No DOM element found at X=${x}, Y=${y}!`);
    }
  }

  // --- SPEECH RECOGNITION ---
  function initSpeech() {
    // SECURITY: If we are running in the Scorer Studio Iframe, 
    // we MUST NOT use the mic. The Parent Dashboard handles voice.
    if (isIframe) {
        logTrace("Mic initialization blocked in Iframe mode (Ghost Mode).");
        return;
    }

    if (!('webkitSpeechRecognition' in window)) {
        logTrace("Your browser does not support SpeechRecognition.");
        return;
    }
    // ... [Speech Init Truncated for Space in Chunk] ...
    recognition = new webkitSpeechRecognition();
    recognition.continuous = true;
    recognition.interimResults = false;
    recognition.lang = 'en-US';

    recognition.onstart = () => {
      isListening = true;
      statusText.textContent = 'Listening...';
      statusDot.classList.add('active');
      toggleMicBtn.textContent = 'Stop Listening';
      toggleMicBtn.classList.remove('primary');
      logTrace("Microphone natively listening...");
    };

    recognition.onend = () => {
      isListening = false;
      statusText.textContent = 'Mic Off';
      statusDot.classList.remove('active');
      toggleMicBtn.textContent = 'Start Listening';
      toggleMicBtn.classList.add('primary');
      // Auto-restart if it was stopped by the browser network timeout
      if (toggleMicBtn.dataset.intendedState === "on") {
        setTimeout(() => { if (!isListening) recognition.start(); }, 1000);
      }
    };

    recognition.onresult = (event) => {
      for (let i = event.resultIndex; i < event.results.length; ++i) {
        if (event.results[i].isFinal) {
          const transcript = event.results[i][0].transcript.trim().toLowerCase();
          logTrace(`Heard: "${transcript}"`);
          processSpeech(transcript);
        }
      }
    };
  }

  function processSpeech(transcript) {
    if (!calibratedCoords.x || !calibratedCoords.y) {
      logTrace("Error: Please Calibrate the input box first!");
      return;
    }

    // Try parsing a dart
    const dart = parseSingleDart(transcript);
    let finalScore = null;

    if (dart) {
      finalScore = dart.val;
    } else {
      // Try raw number fallback
      finalScore = parseScore(transcript);
    }

    if (finalScore !== null) {
      logTrace(`Matched Score: ${finalScore}. Preparing Injection...`);
      // Simulate clicking the box, typing the number, and entering
      simulateScoreEntry(finalScore);
    } else {
      logTrace(`Could not parse: "${transcript}"`);
    }
  }

  function simulateScoreEntry(score) {
    const x = calibratedCoords.x;
    const y = calibratedCoords.y;

    // Click field to focus
    clickCoordinate(x, y);

    setTimeout(() => {
      let el = document.activeElement;
      
      // Fallback: If activeElement is not an input, try to grab the element exactly at the calibrated point
      if (!el || (el.tagName !== 'INPUT' && !el.isContentEditable)) {
          el = document.elementFromPoint(x, y);
      }

      logTrace("Target Element identified for injection:", el);
      
      if (el && (el.tagName === 'INPUT' || el.isContentEditable)) {
        // High-compatibility insertion for React/Vue/Angular
        if (el.tagName === 'INPUT') {
            el.focus();
            el.select();
            document.execCommand('insertText', false, score);
        } else {
            el.textContent = '';
            el.textContent = score;
        }

        // Dispatch events as secondary fallback
        el.dispatchEvent(new Event('input', { bubbles: true }));
        el.dispatchEvent(new Event('change', { bubbles: true }));

        // Dispatch Enter key to submit
        logTrace("Dispatching ENTER key events...");
        el.dispatchEvent(new KeyboardEvent('keydown', { bubbles: true, key: 'Enter', code: 'Enter', keyCode: 13, which: 13 }));
        el.dispatchEvent(new KeyboardEvent('keyup', { bubbles: true, key: 'Enter', code: 'Enter', keyCode: 13, which: 13 }));
      } else {
        logTrace("CRITICAL ERROR: No valid input target found at calibrated coordinates!", {x, y, el});
      }
    }, 150); // Increased timeout slightly to ensure focus/click settle
  }

  toggleMicBtn.addEventListener('click', () => {
    if (!recognition) initSpeech();

    if (isListening) {
      toggleMicBtn.dataset.intendedState = "off";
      recognition.stop();
    } else {
      toggleMicBtn.dataset.intendedState = "on";
      try { recognition.start(); } catch (e) { }
    }
  });

  closeBtn.addEventListener('click', () => {
    if (recognition && isListening) recognition.stop();
    container.remove();
    window.__dartvoiceInjected = false;
  });

  // Make draggable
  let isDragging = false, startX, startY, initialX, initialY;
  panel.addEventListener('mousedown', (e) => {
    if (e.target.tagName === 'BUTTON' || e.target.className === 'close-btn') return;
    isDragging = true;
    startX = e.clientX;
    startY = e.clientY;
    initialX = container.offsetLeft;
    initialY = container.offsetTop;
    container.style.right = 'auto'; // Disable right anchor
  });

  document.addEventListener('mousemove', (e) => {
    if (!isDragging) return;
    container.style.left = (initialX + e.clientX - startX) + 'px';
    container.style.top = (initialY + e.clientY - startY) + 'px';
  });

  document.addEventListener('mouseup', () => { isDragging = false; });

  // --- WEB APP BRIDGE LISTENER ---
  window.addEventListener('message', (event) => {
    // If the parent Web App Dashboard is talking to us
    if (event.data && event.data.type) {
      logTrace("Received Window Payload:", event.data);
      
      if (event.data.type === "DARTVOICE_CALIBRATE_START") {
        startCalibration();
      }
      
      if (event.data.type === "DARTVOICE_SCORE_INJECT") {
        const score = event.data.score;
        if (!calibratedCoords.x || !calibratedCoords.y) {
           logTrace(`Web App sent score: ${score}, but we are NOT CALIBRATED. Ignoring injection.`);
           return;
        }
        
        logTrace(`Web App triggered cross-origin score injection: ${score}`);
        simulateScoreEntry(score);
      }
    }
  });

  // --- SILENT GHOST MODE FOR IFRAME ---
  // If we are running inside the Scorer Studio iframe, we want to be INVISIBLE.
  // The Parent Dashboard handles the UI.
  if (isIframe) {
      container.style.display = 'none';
      logTrace("GHOST MODE ENGAGED: Extension running silently inside iframe.");
  }

})();
